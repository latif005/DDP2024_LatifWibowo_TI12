import math

def persegi(s):
    return s * s

def persegi_panjang(p, l):
    return p * l

def segitiga(a, t):
    return 0.5 * a * t

def lingkaran(r):
    return 3.14 * r * r

def trapesium(a, t, b):
    return 0.5 * (a + b) * t