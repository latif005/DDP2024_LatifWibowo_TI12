from Gempa import *


gempa1 = Gempa('Bantenn', 1.2)
gempa2 = Gempa('Palu', 6.1)
gempa3 = Gempa('Cianjur', 6.4)
gempa4 = Gempa('Jayapura', 3.3)
gempa5 = Gempa('Garut', 4.0)   

print('### Info Gempa ###')
print()
gempa1.dampak()

print('### Info Gempa ###')
print()
gempa2.dampak()

print('### Info Gempa ###')
print()
gempa3.dampak()

print('### Info Gempa ###')
print()
gempa4.dampak()

print('### Info Gempa ###')
print()
gempa5.dampak()