from Animal import Animal

class Ular(Animal):
    def __init__(self, name, makanan, hidup, berkembang_biak, bergerak, gigitan):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.bergerak = bergerak
        self.gigitan = gigitan

    def info_ular(self):
        super().info()
        print("Bergerak\t\t: ", self.bergerak, "\n Gigitan\t\t: ", self.gigitan)

ular = Ular("King Cobra", "Hewan Berdarah Dingin", "Hutan", "Bertelur", "Melata", "Berbisa")
print("### Info Ular ###")
ular.info_ular()