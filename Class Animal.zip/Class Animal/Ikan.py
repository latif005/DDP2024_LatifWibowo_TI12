from Animal import Animal

class Ikan(Animal):
    def __init__(self, name, makanan, hidup, berkembang_biak, bernapas, habitat):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.bernapas = bernapas
        self.habitat = habitat

    def info_ikan(self):
        super().info()
        print("Bernapas\t\t: ", self.bernapas, "\n Habitat\t\t: ", self.habitat)

ikan = Ikan("Koi", "pelet", "Air", "Berteluur", "Organ Labirin", "Air Tawar")
print("### Info Ikan ###")
ikan.info_ikan()