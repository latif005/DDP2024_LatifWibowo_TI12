from Animal import Animal

class Burung(Animal):
    def __init__(self, name, makanan, hidup, berkembang_biak, warna, paruh):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.warna = warna
        self.paruh = paruh

    def info_burung(self):
        super().info()
        print("Warna\t\t\t: ", self.warna, "\n Jenis Paruh\t\t: ", self.paruh)

burung = Burung("Elang", "Daging", "Di Tebing", "Menghasilkan Telur", "Pink", "Bengkok dan Lancip")
print("## Info Bird ##")
burung.info_burung()